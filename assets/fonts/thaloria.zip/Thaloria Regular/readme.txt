Thaloria is not just a font — it is a visual accent that instantly attracts the eye and sets the mood. It is ideal for projects where an atmosphere of sophistication, historical allusion, or artistic audacity is important.

The font is perfect for large headlines and is also suitable for posters, book covers, music albums, and other similar media.

License terms: free for personal and commercial use.

Supports Cyrillic, Latin, numbers, and basic symbols.

The font was created as part of the type designing course at the Alkali studio.  Curator — Vladimir Anosov.

Like and follow:
https://www.behance.net/veragrapes